# Smart Resource Allocation Using Banker's Algorithm

## Project overview
This Operating Systems project demonstrates **Banker's Algorithm**, a deadlock-avoidance algorithm. It calculates the remaining resource needs of each process and checks whether the system is in a safe state.

## Team members
- Srija — `2520090053`
- Praveena — `2520090057`
- Akshitha Reddy — `2520090178`

## Features
- Accepts the number of processes and resource types.
- Reads the Allocation, Maximum, and Available resource values.
- Calculates the Need matrix using `Need = Max - Allocation`.
- Checks whether the system is in a safe state.
- Displays a safe sequence when one exists.
- Validates basic input values.

## Requirements
- Ubuntu/Linux or another system with GCC installed.

## Compile and run on Ubuntu
```bash
gcc -Wall -Wextra -std=c11 bankers.c -o bankers
./bankers
```

If GCC is not installed:
```bash
sudo apt update
sudo apt install build-essential
```

## Sample input
Use this input, entering each line when prompted:

```text
3
2
1 0
1 1
1 0
3 2
1 2
2 1
1 1
```

## Expected result
The Need matrix should be:
```text
P0: 2 2
P1: 0 1
P2: 1 1
```

The system should report a safe state with a safe sequence:
```text
P1 -> P2 -> P0
```

## Algorithm summary
1. Read the Allocation, Max, and Available values.
2. Calculate `Need = Max - Allocation`.
3. Copy Available into a temporary Work vector.
4. Find an unfinished process whose Need is less than or equal to Work.
5. Treat that process as finished and add its Allocation to Work.
6. Repeat until all processes finish or no eligible process can be found.
7. If all processes finish, print the safe sequence; otherwise, report an unsafe state.

## Limitations
- Supports up to 10 processes and 10 resource types.
- This is a terminal-based demonstration; it does not include a graphical interface or a resource-request module.
