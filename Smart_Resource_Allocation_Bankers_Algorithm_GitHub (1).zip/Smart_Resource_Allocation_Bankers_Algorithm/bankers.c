/*
 * Project: Smart Resource Allocation Using Banker's Algorithm
 * Team:
 *   Srija - 2520090053
 *   Praveena - 2520090057
 *   Akshitha Reddy - 2520090178
 *
 * Description:
 * Calculates the Need matrix and checks whether the current resource
 * allocation is safe. Supports up to 10 processes and 10 resource types.
 */

#include <stdio.h>

#define MAX 10

int main(void) {
    int n, m;
    int allocation[MAX][MAX], max[MAX][MAX];
    int need[MAX][MAX], available[MAX];
    int work[MAX], finish[MAX] = {0};
    int safeSequence[MAX], count = 0;

    printf("=== Smart Resource Allocation Using Banker's Algorithm ===\n");

    printf("Enter number of processes (1-10): ");
    if (scanf("%d", &n) != 1 || n < 1 || n > MAX) {
        printf("Invalid number of processes.\n");
        return 1;
    }

    printf("Enter number of resource types (1-10): ");
    if (scanf("%d", &m) != 1 || m < 1 || m > MAX) {
        printf("Invalid number of resource types.\n");
        return 1;
    }

    printf("\nEnter Allocation Matrix:\n");
    for (int i = 0; i < n; i++) {
        printf("P%d: ", i);
        for (int j = 0; j < m; j++) {
            if (scanf("%d", &allocation[i][j]) != 1 ||
                allocation[i][j] < 0) {
                printf("Invalid allocation value.\n");
                return 1;
            }
        }
    }

    printf("\nEnter Maximum (Max) Matrix:\n");
    for (int i = 0; i < n; i++) {
        printf("P%d: ", i);
        for (int j = 0; j < m; j++) {
            if (scanf("%d", &max[i][j]) != 1 ||
                max[i][j] < allocation[i][j]) {
                printf("Max must be greater than or equal to Allocation.\n");
                return 1;
            }
            need[i][j] = max[i][j] - allocation[i][j];
        }
    }

    printf("\nEnter Available Resources (%d values): ", m);
    for (int j = 0; j < m; j++) {
        if (scanf("%d", &available[j]) != 1 || available[j] < 0) {
            printf("Invalid Available value.\n");
            return 1;
        }
    }

    printf("\nNeed Matrix (Need = Max - Allocation):\n");
    for (int i = 0; i < n; i++) {
        printf("P%d: ", i);
        for (int j = 0; j < m; j++) {
            printf("%d ", need[i][j]);
        }
        printf("\n");
    }

    for (int j = 0; j < m; j++) {
        work[j] = available[j];
    }

    while (count < n) {
        int found = 0;

        for (int i = 0; i < n; i++) {
            if (!finish[i]) {
                int canFinish = 1;

                for (int j = 0; j < m; j++) {
                    if (need[i][j] > work[j]) {
                        canFinish = 0;
                        break;
                    }
                }

                if (canFinish) {
                    for (int j = 0; j < m; j++) {
                        work[j] += allocation[i][j];
                    }

                    safeSequence[count++] = i;
                    finish[i] = 1;
                    found = 1;
                }
            }
        }

        if (!found) {
            break;
        }
    }

    if (count == n) {
        printf("\nSystem is in a SAFE state.\n");
        printf("Safe Sequence: ");
        for (int i = 0; i < n; i++) {
            printf("P%d", safeSequence[i]);
            if (i < n - 1) {
                printf(" -> ");
            }
        }
        printf("\n");
    } else {
        printf("\nSystem is in an UNSAFE state.\n");
        printf("No safe sequence exists for this input.\n");
    }

    return 0;
}
